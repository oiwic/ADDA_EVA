 function data = Step(data)
    data = reshape(data',1,[]);
end
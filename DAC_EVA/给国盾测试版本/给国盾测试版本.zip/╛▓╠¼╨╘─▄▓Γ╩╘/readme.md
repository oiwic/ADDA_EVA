1. 安装python https://www.python.org/ftp/python/3.4.4/python-3.4.4.amd64.msi  
2. 在Python中安装jinja2 pip install jinja2 最好是版本jinja2-2.9.6  
2. 在matlab中配置python pyversion 'python安装路径'  
4. a=csvsaver;  
5. a.setdata('mubiaozengyi2',1.3);  
6. a.readstruct(struct('ceshibanhao','aaa','mubiaozengyi1','1.22'));  
7. a.savefile()  

